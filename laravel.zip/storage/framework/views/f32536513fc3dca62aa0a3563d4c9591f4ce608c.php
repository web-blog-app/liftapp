

<header>
<div class="main-header ">
      <img src="elevator.png" alt="Логотип" class="logo">
      <nav>
        <ul class="menu">
          <li><a href="/laravel/public/">текущие дела</a></li>
          <li><a href="/laravel/public/requestBook">книга заявок</a></li>
          <li><a href="/laravel/public/detail">необходимые детали</a></li>
          <li><a href="/laravel/public/changeDetail">замена деталей</a></li>          
        </ul>
      </nav>
  
<button class="toggle-menu">
      <span class="sandwich">
      <span class="sw-topper"></span>
      <span class="sw-bottom"></span>
      <span class="sw-footer"></span>
      </span>
</button>

<div class="top-menu">
<ul>
  <li><a href="/laravel/public/">текущие дела</a></li>
  <li><a href="/laravel/public/requestBook">книга заявок</a></li>
  <li><a href="/laravel/public/detail">необходимые детали</a></li>
  <li><a href="/laravel/public/changeDetail">замена деталей</a></li>
</ul>      
</div>
</div>
</header >
